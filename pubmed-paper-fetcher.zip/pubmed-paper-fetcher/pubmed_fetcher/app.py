from flask import Flask, jsonify, Response
import json
import csv
from fetch_papers import fetch_paper_details  # Import function from fetch_papers

app = Flask(__name__)

@app.route('/fetch', methods=['GET'])
def fetch():
    paper_ids = ['40053389', '40053387', '40053353', '40053349', '40053343', '40053336', '40053308', '40053290', '40053285', '40053281', '40053279', '40053271', '40053269', '40053268', '40053265', '40053260', '40053258', '40053257', '40053253', '40053252']

    papers = fetch_paper_details(paper_ids)  # Fetch paper details
    with open("papers.json", "w", encoding="utf-8") as json_file:
        json.dump(papers, json_file, indent=4, ensure_ascii=False)
    print("📂 Paper details saved to papers.json")  # Console log
    return jsonify(papers)  # Return as JSON

# ✅ New Route for Exporting CSV
@app.route('/export/csv', methods=['GET'])
def export_csv():
    try:
        with open("papers.json", "r", encoding="utf-8") as json_file:
            papers = json.load(json_file)  # Load stored papers
        if not papers:
            return jsonify({"error":"No paper data available.Please fetch first."}), 400    

        output = "ID,Title,Abstract\n"
        for paper in papers:
            output += f'"{paper["id"]}","{paper["title"]}","{paper["abstract"]}"\n'

        response = Response(output, content_type="text/csv")
        response.headers["Content-Disposition"] = "attachment; filename=papers.csv"
        return response
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
