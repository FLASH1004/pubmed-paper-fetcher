import requests
import json

def fetch_papers(query):
    """Fetches paper IDs from PubMed based on a search query."""
    search_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={query}&retmode=json"
    search_response = requests.get(search_url)
    
    if search_response.status_code == 200:
        search_data = search_response.json()
        paper_ids = search_data["esearchresult"]["idlist"]
        print("Paper IDs:", paper_ids)
        
        # Fetch paper details (titles + abstracts)
        fetch_paper_details(paper_ids)
    else:
        print("Error fetching papers:", search_response.status_code)

def fetch_paper_details(paper_ids):
    """Fetches titles and abstracts of given paper IDs."""
    if not paper_ids:
        print("No paper IDs found.")
        return []

    details_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id={','.join(paper_ids)}&retmode=json"
    abstract_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id={','.join(paper_ids)}&rettype=abstract&retmode=text"

    details_response = requests.get(details_url)
    abstract_response = requests.get(abstract_url)

    if details_response.status_code == 200 and abstract_response.status_code == 200:
        details_data = details_response.json()
        abstracts = abstract_response.text.split("\n\n")  # Split abstracts by new lines

        paper_list = []
        for idx, paper_id in enumerate(paper_ids):
            paper_info = details_data["result"].get(paper_id, {})
            title = paper_info.get("title", "No title found")
            abstract = abstracts[idx] if idx < len(abstracts) else "No abstract found"
            
            print(f"📄 {paper_id}: {title}\n📝 Abstract: {abstract}\n")
            paper_list.append({"id": paper_id, "title": title, "abstract": abstract})

        # Save the results to a JSON file
        save_to_json(paper_list)

        return paper_list  # ✅ FIXED: Now the function returns data!
    else:
        print("Error fetching paper details or abstracts.")
        return []


def save_to_json(data):
    """Saves the fetched paper details into a JSON file."""
    with open("papers.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    print("📂 Paper details saved to papers.json")

if __name__ == "__main__":
    query = "cancer"  # Test query
    fetch_papers(query)
